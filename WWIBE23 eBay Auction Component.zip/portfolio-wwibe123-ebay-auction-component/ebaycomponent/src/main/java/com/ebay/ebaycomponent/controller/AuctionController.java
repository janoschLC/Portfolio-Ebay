package com.ebay.ebaycomponent.controller;

import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.ebay.ebaycomponent.model.Auction;
import com.ebay.ebaycomponent.model.Bid;
import com.ebay.ebaycomponent.model.Product;
import com.ebay.ebaycomponent.model.User;
import com.ebay.ebaycomponent.repository.UserRepository;
import com.ebay.ebaycomponent.service.AuctionService;

@Controller
@RequestMapping("/auctions")
public class AuctionController {

    private final AuctionService auctionService;
    private final UserRepository userRepository;

    public AuctionController(AuctionService auctionService, UserRepository userRepository) {
        this.userRepository = userRepository;
        this.auctionService = auctionService;
    }

    // Endpunkt, um eine Auktion anhand ihrer ID abzurufen
    @GetMapping("/{id}")
    public ResponseEntity<Auction> getAuction(@PathVariable Long id) {
        Optional<Auction> auction = auctionService.getAuction(id);
        return auction.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/create-auction")
    public String showAuctionForm(Model model) {

        Auction auction = new Auction();

        auction.setProduct(new Product());
        model.addAttribute("auction", auction);
        return "createauction";
    }

    @PostMapping("/create-auction")
    public String processAuctionCreation(@ModelAttribute("auction") Auction auction) {
        Auction createdAuction = auctionService.createAuction(auction);

        System.out.println("ProduktId" + createdAuction.getProduct().getId());
        return "redirect:/auctions/product/" + createdAuction.getProduct().getId();
    }

    // Zeigt die Auktionsdetails anhand der ProduktId an, inklusive Gebotsformular
    @GetMapping("/product/{productId}")
    public String showAuctionByProductId(@PathVariable Long productId, Model model) {
        Optional<Auction> auctionOpt = auctionService.getAuctionByProductId(productId);
        if (auctionOpt.isEmpty()) {
            throw new RuntimeException("Auktion für Produkt-ID " + productId + " nicht gefunden.");
        }
        model.addAttribute("auction", auctionOpt.get());
        model.addAttribute("bid", new Bid());
        return "auctiondetails";
    }

    @PostMapping("/product/{productId}/bid")
    public String processBidByProductId(@PathVariable Long productId,
            @ModelAttribute("bid") Bid bid,
            Model model) {
        Optional<Auction> auctionOpt = auctionService.getAuctionByProductId(productId);
        if (auctionOpt.isEmpty()) {
            throw new RuntimeException(
                    "Auktion zum Abgeben eines Gebots für Produkt-ID " + productId + " nicht gefunden.");
        }
        Auction auction = auctionOpt.get();

        // Es wird der Bidder genommen aus dem Formular
        Optional<User> bidder = userRepository.findByEmail(bid.getBidder().getEmail());
        if (bidder.isEmpty()) {
            throw new RuntimeException("Kein User mit der E-Mail gefunden.");
        }

        // Überprüfen, ob das übergebene Passwort korrekt ist
        if (!bid.getBidder().getPassword().equals(bidder.get().getPassword())) {
            throw new RuntimeException("Falsches Passwort.");
        }

        // Verhindern, dass der Seller auf seine eigene Auktion bietet.
        if (auction.getSeller() != null && auction.getSeller().getId().equals(bidder.get().getId())) {
            throw new RuntimeException("Sie können nicht auf Ihre eigene Auktion bieten.");
        }

        bid.setBidder(bidder.get());

        auctionService.placeBidByProductId(productId, bid);
        return "redirect:/auctions/product/" + productId;
    }
}