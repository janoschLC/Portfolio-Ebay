package com.ebay.ebaycomponent.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ebay.ebaycomponent.model.Auction;
import com.ebay.ebaycomponent.model.User;

@Repository
public interface AuctionRepository extends JpaRepository<Auction, Long> {

    // Suche nach Auktionen anhand ihres Status (z. B. "RUNNING", "FINISHED")
    List<Auction> findByStatus(String status);

    // Suche nach Auktionen, die aktuell aktiv sind:
    // (Startzeit liegt in der Vergangenheit und Endzeit in der Zukunft)
    List<Auction> findByStartTimeBeforeAndEndTimeAfter(LocalDateTime now1, LocalDateTime now2);

    // für delete operation
    List<Auction> findBySellerAndStatus(User seller, String status);

    Optional<Auction> findByProduct_Name(String productName);

    Optional<Auction> findByProduct_Id(Long productId);

    @Modifying
    @Query("UPDATE Auction a SET a.status = 'CLOSED' WHERE a.status = 'RUNNING' AND a.endTime < :now")
    int closeEndedAuctions(LocalDateTime now);
}
