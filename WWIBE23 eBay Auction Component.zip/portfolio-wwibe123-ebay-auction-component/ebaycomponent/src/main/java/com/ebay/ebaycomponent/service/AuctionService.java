package com.ebay.ebaycomponent.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ebay.ebaycomponent.model.Auction;
import com.ebay.ebaycomponent.model.Bid;
import com.ebay.ebaycomponent.model.Product;
import com.ebay.ebaycomponent.model.User;
import com.ebay.ebaycomponent.repository.AuctionRepository;
import com.ebay.ebaycomponent.repository.BidRepository;
import com.ebay.ebaycomponent.repository.ProductRepository;
import com.ebay.ebaycomponent.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class AuctionService {

    private final AuctionRepository auctionRepository;
    private final BidRepository bidRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    // Konstruktor-Injektion der benötigten Repositories
    public AuctionService(AuctionRepository auctionRepository, BidRepository bidRepository,
            ProductRepository productRepository, UserRepository userRepository) {
        this.auctionRepository = auctionRepository;
        this.bidRepository = bidRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    public Optional<Auction> getAuction(Long id) {
        return auctionRepository.findById(id);
    }

    public Optional<Auction> getAuctionByName(String name) {
        return auctionRepository.findByProduct_Name(name);
    }

    public Optional<Auction> getAuctionByProductId(Long productId) {
        return auctionRepository.findByProduct_Id(productId);
    }

    // Methode zum Erstellen einer neuen Auktion
    public Auction createAuction(Auction auction) {

        if (auction.getProduct() != null) {
            Product inputProduct = auction.getProduct();
            Product finalProduct;
            if (inputProduct.getId() != null) {
                // Produkt anhand der ID laden
                finalProduct = productRepository.findById(inputProduct.getId())
                        .orElseThrow(() -> new RuntimeException("Product not found"));
            } else {
                // Produkt anhand des Namens laden oder neu anlegen
                if (inputProduct.getName() == null || inputProduct.getName().trim().isEmpty()) {
                    throw new IllegalArgumentException("Produktname muss angegeben sein.");
                }

                Product product = productRepository.findByName(inputProduct.getName());
                if (product != null) {
                    finalProduct = product;
                } else {
                    // Produkt anlegen, falls es noch nicht existiert
                    finalProduct = productRepository.save(inputProduct);
                }
            }
            auction.setProduct(finalProduct);
        } else {
            throw new IllegalArgumentException("Produkt muss angegeben sein.");
        }

        // Seller-Daten validieren (E-Mail und Passwort müssen gesetzt sein)
        if (auction.getSeller() != null &&
                auction.getSeller().getEmail() != null &&
                auction.getSeller().getPassword() != null) {

            User seller = userRepository.findByEmail(auction.getSeller().getEmail())
                    .orElseThrow(
                            () -> new RuntimeException("Seller nicht gefunden. Bitte registrieren Sie sich zuerst."));

            if (!seller.getPassword().equals(auction.getSeller().getPassword())) {
                throw new RuntimeException("Falsches Passwort für den Seller.");
            }
            auction.setSeller(seller);

        } else {
            throw new IllegalArgumentException("Seller-Daten (E-Mail und Passwort) müssen angegeben werden.");
        }

        // Validierung: Check Start- und Endzeiten
        if (auction.getStartTime() == null || auction.getEndTime() == null) {
            throw new IllegalArgumentException("StartTime und EndTime müssen gesetzt sein.");
        }
        if (auction.getEndTime().isBefore(auction.getStartTime())) {
            throw new IllegalArgumentException("EndTime muss nach StartTime liegen.");
        }

        // Setze initial den Status auf RUNNING und speichere die Auktion
        auction.setStatus("RUNNING");

        return auctionRepository.save(auction);
    }

    @Transactional
    public Bid placeBidByProductId(Long productId, Bid bid) {
        // Suche die Auktion anhand der Produkt-ID
        Auction auction = auctionRepository.findByProduct_Id(productId)
                .orElseThrow(() -> new RuntimeException("Auktion nicht gefunden"));

        LocalDateTime now = LocalDateTime.now();
        if (!"RUNNING".equals(auction.getStatus())) {
            throw new RuntimeException("Die Auktion ist nicht aktiv, da ihr Status '" + auction.getStatus() + "' ist.");
        }
        if (now.isBefore(auction.getStartTime())) {
            throw new RuntimeException("Die Auktion hat noch nicht begonnen.");
        }
        if (now.isAfter(auction.getEndTime())) {
            throw new RuntimeException("Die Auktion ist bereits beendet.");
        }

        // Bid-Validierung anhand der bisherigen Gebote der Auktion
        var bids = bidRepository.findByAuctionOrderByAmountDesc(auction);
        if (!bids.isEmpty()) {
            // Das erste Element in der Liste ist das höchste Gebot.
            Bid highestBid = bids.get(0);
            if (bid.getAmount() <= highestBid.getAmount()) {
                throw new RuntimeException("Das neue Gebot (" + bid.getAmount()
                        + ") muss höher sein als das aktuelle Höchstgebot (" + highestBid.getAmount() + ").");
            }
        } else {
            // Falls noch keine Gebote abgegeben wurden, muss das Gebot mindestens dem
            // Startpreis entsprechen.
            if (bid.getAmount() < auction.getStartingprice()) {
                throw new RuntimeException("Das Gebot (" + bid.getAmount()
                        + ") muss mindestens so hoch sein wie der Startpreis (" + auction.getStartingprice() + ").");
            }
        }

        

        // Setze die aktuelle Zeit als Gebotszeit und verknüpfe das Gebot mit der
        // Auktion
        bid.setBidTime(now);
        bid.setAuction(auction);

        Bid savedBid = bidRepository.save(bid);

        // Aktualisiere das Gewinnerfeld in der Auktion mit dem neuen höchsten Gebot
        auction.setWinningBid(savedBid);
        auctionRepository.save(auction);

        return savedBid;
    }
}
