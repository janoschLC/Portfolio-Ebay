package com.ebay.ebaycomponent.controller;

import java.util.Optional;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.ebay.ebaycomponent.model.User;
import com.ebay.ebaycomponent.service.UserService;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    // Konstruktor
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Endpunkt, um einen Benutzer anhand seiner ID abzurufen.
    @GetMapping("/{id}")
    public ResponseEntity<User> getUser(@PathVariable Long id) {
        Optional<User> user = userService.getUserById(id);
        return user.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Mapping für die Startseite
    @GetMapping("/register") // Zeigt das Registrierungsformular für einen neuen Benutzer an
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "userform";
    }

    // Mapping für das Registrierungsformular
    @PostMapping("/register")
    public String processRegistration(@ModelAttribute("user") User user) {

        userService.createUser(user);

        return "redirect:/success";
    }

}