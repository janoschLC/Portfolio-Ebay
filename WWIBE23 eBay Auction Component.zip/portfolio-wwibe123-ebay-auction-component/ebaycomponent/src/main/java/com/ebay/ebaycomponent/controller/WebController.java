package com.ebay.ebaycomponent.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class WebController {

    public WebController() {
    }

    // Mapping für die Erfolgsseite
    @GetMapping("/success")
    public String showSuccessPage(@RequestParam(required = false) Long productId, Model model) {
        model.addAttribute("productId", productId);
        return "success";
    }

    // Benutzerdefinierter Error-Endpunkt, der für alle Fehler aufgerufen wird.
    @GetMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        model.addAttribute("errorMessage", "Ein Fehler ist aufgetreten. Statuscode: " + status);
        return "error"; // Hierbei wird die error.html im templates-Ordner verwendet.
    }

}
