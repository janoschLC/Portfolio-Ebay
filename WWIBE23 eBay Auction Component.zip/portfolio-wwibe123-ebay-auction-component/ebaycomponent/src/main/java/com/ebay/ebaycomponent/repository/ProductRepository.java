package com.ebay.ebaycomponent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ebay.ebaycomponent.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    // Suche nach dem Produkt nach der ID
    Product findById(long id);

    // Suche nach dem Produkt nach dem Namen
    Product findByName(String name);
}
