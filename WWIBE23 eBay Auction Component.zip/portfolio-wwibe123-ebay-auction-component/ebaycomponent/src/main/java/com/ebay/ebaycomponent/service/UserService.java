package com.ebay.ebaycomponent.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ebay.ebaycomponent.model.Auction;
import com.ebay.ebaycomponent.model.User;
import com.ebay.ebaycomponent.repository.UserRepository;
import com.ebay.ebaycomponent.repository.AuctionRepository;


//CRUD-Operationen für User
@Service
public class UserService {

    private final UserRepository userRepository;
    private final AuctionRepository auctionRepository;

    // Konstruktor-Injektion des UserRepository
    public UserService(UserRepository userRepository, AuctionRepository auctionRepository) {
        this.userRepository = userRepository;
        this.auctionRepository = auctionRepository;
    }   

    public User createUser(User user) {
        // Hier könntest du z.B. Validierungen oder Passwort-Hashing einbauen.
        return userRepository.save(user);
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public User updateUser(Long id, User updatedUser) {
        return userRepository.findById(id)
                .map(existingUser -> {
                    existingUser.setName(updatedUser.getName());
                    existingUser.setEmail(updatedUser.getEmail());
                    existingUser.setPassword(updatedUser.getPassword());
                    return userRepository.save(existingUser);
                })
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
    }

    public void deleteUser(Long id) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (!optionalUser.isPresent()) {
            throw new RuntimeException("User not found with id: " + id);
        }
        User user = optionalUser.get();

        // Prüfe, ob der User laufende Auktionen hat
        List<Auction> runningAuctions = auctionRepository.findBySellerAndStatus(user, "RUNNING");
        if (runningAuctions != null && !runningAuctions.isEmpty()) {
            throw new RuntimeException("User cannot be deleted because he has running auctions.");
        }

        userRepository.deleteById(id);
    }
}