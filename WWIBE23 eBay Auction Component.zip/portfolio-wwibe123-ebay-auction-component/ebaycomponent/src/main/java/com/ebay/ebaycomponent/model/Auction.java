package com.ebay.ebaycomponent.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Getter
@Setter

@Entity
public class Auction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Double startingprice;
    private String status; // running, closed, cancelled

    @OneToOne
    @JoinColumn(name = "winning_bid_id")
    private Bid winningBid;

    public Auction() {
    }

    public Auction(LocalDateTime startTime, LocalDateTime endTime, Double startingprice, String status, Product product,
            User seller, List<Bid> bids) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.startingprice = startingprice;
        this.status = status;
        this.product = product;
        this.seller = seller;
        this.bids = bids;
    }

    // Relation to Product -> OneToOne
    @OneToOne(cascade = CascadeType.ALL) // CascadeType.ALL: Wenn die Auktion gelöscht wird, wird auch das Produkt
                                         // gelöscht
    @JoinColumn(name = "product_id")
    private Product product;
    // Relation to User -> ManyToOne
    @ManyToOne
    @JoinColumn(name = "seller_id")
    @JsonBackReference
    private User seller;

    // Relation to Bids -> OneToMany
    @OneToMany(mappedBy = "auction", cascade = CascadeType.ALL)
    @JsonManagedReference // sorgt dafür, dass bei der Serialisierung von Auction die Bids eingebunden
                          // werden, ohne erneut Auction zu serialisieren
    private List<Bid> bids;

    public void addBid(Bid bid) {
        this.bids.add(bid);
    }

    public void removeBid(Bid bid) {
        this.bids.remove(bid);
    }

    public void updateBid(Bid bid) {
        for (int i = 0; i < bids.size(); i++) {
            if (bids.get(i).getId() == bid.getId()) {
                bids.set(i, bid);
            }
        }
    }

    public void updateAuction(Auction auction) {
        this.startTime = auction.getStartTime();
        this.endTime = auction.getEndTime();
        this.startingprice = auction.getStartingprice();
        this.status = auction.getStatus();
        this.product = auction.getProduct();
        this.seller = auction.getSeller();
        this.bids = auction.getBids();
        this.winningBid = auction.getWinningBid();
    }

    public void removeBids() {
        this.bids.clear();
    }

    public void removeProduct() {
        this.product = null;
    }

    public void removeSeller() {
        this.seller = null;
    }

    public void removeBidById(Long id) {
        for (int i = 0; i < bids.size(); i++) {
            if (bids.get(i).getId() == id) {
                bids.remove(i);
            }
        }
    }

    public void removeBidByUser(User bidder) {
        for (int i = 0; i < bids.size(); i++) {
            if (bids.get(i).getBidder().getId() == bidder.getId()) {
                bids.remove(i);
            }
        }
    }

}
