package com.ebay.ebaycomponent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ebay.ebaycomponent.model.Bid;
import com.ebay.ebaycomponent.model.Auction;

@Repository
public interface BidRepository extends JpaRepository<Bid, Long> {

    // 1. Alle Gebote zu einer bestimmten Auktion, sortiert nach dem Gebotsbetrag
    // (absteigend: höchstes Gebot zuerst)
    List<Bid> findByAuctionOrderByAmountDesc(Auction auction);

    // 2. Alle Gebote eines bestimmten Bidders, anhand des Benutzernamens
    List<Bid> findByBidderName(String name);

    // 3. Alle Gebote zu einer bestimmten Auktion, bei denen der Gebotsbetrag einen
    // bestimmten Wert übersteigt
    List<Bid> findByAuctionIdAndAmountGreaterThan(Long auctionId, Double amount);
}