package com.ebay.ebaycomponent.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ebay.ebaycomponent.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    //Exakte Suche: Suche einen User anhand seines exakten Benutzernamens.
    Optional<User> findByName(String name);

    //Teilstring-Suche: Suche nach Users, deren E-Mail einen bestimmten String enthält (Groß-/Kleinschreibung ignoriert).
    Optional<User> findByEmail(String email);

    //Kombinierte Suche: Suche einen User, entweder anhand des Benutzernamens oder der E-Mail.
    // Optional<User> findByUsernameOrEmail(String username, String email);
}
