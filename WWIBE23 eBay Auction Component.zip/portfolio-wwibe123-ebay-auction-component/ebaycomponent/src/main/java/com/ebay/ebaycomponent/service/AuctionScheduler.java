package com.ebay.ebaycomponent.service;

import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ebay.ebaycomponent.repository.AuctionRepository;

import jakarta.transaction.Transactional;

@Component
public class AuctionScheduler {

    private final AuctionRepository auctionRepository;

    public AuctionScheduler(AuctionRepository auctionRepository) {
        this.auctionRepository = auctionRepository;
    }

    @Transactional
    @Scheduled(fixedRate = 120000) // alle 120 Sekunden
    public void closeEndedAuctions() { // Methode zum Schließen beendeter Auktionen mithilfe der Query in der AuctionRepository
        int updated = auctionRepository.closeEndedAuctions(LocalDateTime.now()); 
        System.out.println("Prüfe auf beendete Auktionen... " + updated + " Auktionen geschlossen.");
    }
}
