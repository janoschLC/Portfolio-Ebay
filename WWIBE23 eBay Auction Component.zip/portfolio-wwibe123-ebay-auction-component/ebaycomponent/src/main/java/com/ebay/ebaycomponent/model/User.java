package com.ebay.ebaycomponent.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String password;

    // list of created auctions
    @OneToMany(mappedBy = "seller", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Auction> auctions;

    // list of bids
    @OneToMany(mappedBy = "bidder", cascade = CascadeType.ALL)
    private List<Bid> bids;

    // Standardkonstruktor
    public User() {
    }

    // Konstruktor
    public User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

}
