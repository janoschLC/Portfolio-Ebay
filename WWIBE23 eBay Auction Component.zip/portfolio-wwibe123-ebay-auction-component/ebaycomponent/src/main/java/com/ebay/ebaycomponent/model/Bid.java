package com.ebay.ebaycomponent.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Entity
public class Bid {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double amount;
    private LocalDateTime bidTime;

    // Relation to Auction -> ManyToOne
    @ManyToOne
    @JoinColumn(name = "auction_id")
    @JsonBackReference
    private Auction auction;

    // Relation to User -> ManyToOne
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User bidder;

    // Standardkonstruktor
    public Bid() {
    }

    // Constructor

    public Bid(Double amount, LocalDateTime bidTime, Auction auction, User bidder) {
        this.amount = amount;
        this.bidTime = bidTime;
        this.auction = auction;
        this.bidder = bidder;
    }

    @Override

    public String toString() {
        return "Bid{" +
                "id=" + id +
                ", amount=" + amount +
                ", bidTime=" + bidTime +
                ", auction=" + auction +
                ", bidder=" + bidder +
                '}';
    }
}
