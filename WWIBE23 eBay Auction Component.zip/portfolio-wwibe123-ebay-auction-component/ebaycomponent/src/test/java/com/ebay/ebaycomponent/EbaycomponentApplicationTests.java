package com.ebay.ebaycomponent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbaycomponentApplicationTests {

	@Test
	void contextLoads() {
	}

}
